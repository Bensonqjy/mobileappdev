import React from 'react'
import { View } from 'react-native';

const LoginComponent = () => {
  return (
    <View>
      <Text>Login Page</Text>
      <Button title="Login with Microsoft" onPress={loginWithMicrosoft} />
    </View>
  )
}

export default LoginComponent;