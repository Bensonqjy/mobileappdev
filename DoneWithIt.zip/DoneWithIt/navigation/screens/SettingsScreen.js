import * as React from 'react'
import { View, Text, SafeAreaView, ScrollView, StyleSheet, TextInput, TouchableOpacity, Button } from 'react-native'
import { useState, useEffect } from 'react'

const SettingsScreen = ({navigation})=> {
    const [buttonClicked, setButtonClicked] = useState(false);

    useEffect(()=>{

    }, [buttonClicked]);

    return (
        <ScrollView style={{backgroundColor: "paleturquoise"}}>
        { buttonClicked === true ? (
            <SafeAreaView>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Employee No:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Main-Category:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Category:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Sub-Category:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Description:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> File Attached:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Submitted Date:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Submitted By:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <Button title="Edit"/>
                <Button title="Delete"/>
                <TouchableOpacity style={styles.buttonContainer} onPress={()=>setButtonClicked(false)}>
                    <Text style={{fontSize: 20, fontWeight: 'bold'}}>Back to Search</Text>
                </TouchableOpacity>
            </SafeAreaView>
        ) : (
            <SafeAreaView style={styles.mainContainer}>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Employee No:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Employee Name:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Employee SGGID:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <View style={styles.rowContainer}>
                    <Text style={styles.textComponent}> Department:</Text>
                    <TextInput
                        placeholder='Enter Details'
                        style={styles.textInputComponent}
                    />
                </View>
                <TouchableOpacity style={styles.buttonContainer} onPress={()=>setButtonClicked(true)}>
                    <Text style={{fontSize: 20, fontWeight: 'bold'}}>Retrieve Files</Text>
                </TouchableOpacity>
            </SafeAreaView>
        )}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    mainContainer: {
        margin: '2%',
    },
    rowContainer: {
        margin: '2%',
        display: 'flex',
        flexDirection: 'row',
    },
    textComponent: {
        fontSize: 20,
        flex: 1,
        textAlign: 'right',
        marginRight: '5%'
    },
    textInputComponent: {
        borderColor: 'grey',
        borderRadius: 15,
        borderWidth: 2,
        fontSize: 15,
        backgroundColor: 'white',
        flex: 1,
        paddingLeft: '2%',
    },
    buttonContainer: {
        backgroundColor: 'red',
        borderRadius: 15,
        borderColor: 'black',
        borderWidth: 3,
        paddingLeft: '2%',
        marginTop: '3%',
        width: '50%',
        alignSelf: 'center', // Center the button horizontally
        alignItems: 'center', // Center the button vertically
    },

      
  });

export default SettingsScreen;