import * as React from 'react'
import {View,Text ,TouchableOpacity,SafeAreaView ,onPress , TextInput , ScrollView ,StyleSheet,Button } from 'react-native'
import { useNavigation } from '@react-navigation/native'; 
import { useState, useEffect } from 'react'


const RetrievalScreen = ({navigation})=> {
  const [buttonClicked, setButtonClicked] = useState(false);

  useEffect(()=>{

  }, [buttonClicked]);

    return (
      <SafeAreaView style={styles.container}>
        { buttonClicked === true ? (
            <SafeAreaView>

                <Text style = {styles.textheader}>Employee No: </Text>
                <TextInput
                  editable = {false}
                  style = {styles.textoutputENO}
                />

                <Text style ={styles.textheader}>Main-Category: </Text>
                <TextInput
                  editable = {false}
                  style = {styles.textoutputMC}
                />

                <Text style ={styles.textheader}>Category: </Text>
                <TextInput
                  editable = {false}
                  style = {styles.textoutputC}
                />

                <Text style ={styles.textheader}>Sub-Category: </Text>
                <TextInput
                  editable = {false}
                  style = {styles.textoutputSC}
                />

                <Text style ={styles.textheader}>Description: </Text>
                  <TextInput
                      editable = {false}
                      style = {styles.textoutputDesc}
                  />

                <Text style ={styles.textheader}>File Attached: </Text>
                  <TextInput
                      editable = {false}
                      style = {styles.textoutputF}
                  />

                <Text style ={styles.textheader}>Submitted Date: </Text>
                  <TextInput
                      editable = {false}
                      style = {styles.textoutputSD}
                  />

                <Text style ={styles.textheader}>Submitted By: </Text>
                <TextInput
                      editable = {false}
                      style = {styles.textoutputSB}
                  />

                <Button title="Edit"/>
                <Button title="Delete"/>
                <TouchableOpacity style={styles.button} onPress={()=>setButtonClicked(false)}>
                    <Text style={styles.buttontext}>Back to Search</Text>
                </TouchableOpacity>
            </SafeAreaView>
        ) : (
            <SafeAreaView style={styles1.container}>

                    <Text style={styles1.textheader}> Employee No:</Text>
                    <TextInput
                        editable = {false}
                        style={styles1.textinputENO}>
                          <Text style={styles.text}>123456</Text></TextInput>


                    <Text style={styles1.textheader}> Employee Name:</Text>
                    <TextInput
                        editable = {false}
                        style={styles1.textinputENA}
                    > <Text style={styles.text}>Jeremy Sio</Text></TextInput>


                    <Text style={styles1.textheader}> Employee SGGID:</Text>
                    <TextInput
                        editable = {false}
                        style={styles1.textinputSGG}
                    ><Text style={styles.text}>SGG12345</Text></TextInput>
  

                    <Text style={styles1.textheader}> Department:</Text>
                    <TextInput
                        editable = {false}
                        style={styles1.textinputDP}
                    ><Text style={styles.text}>INFORMATION TECHNOLOGY</Text></TextInput>
 
                <TouchableOpacity style={styles1.button} onPress={()=>setButtonClicked(true)}>
                    <Text style={styles1.buttontext}>Retrieve Files</Text>
                </TouchableOpacity>
            </SafeAreaView>
        )}
        </SafeAreaView>
    );
  };


  const styles = StyleSheet.create({
    container: {
    flex: 1,
      backgroundColor: "paleturquoise",
    },

    textheader:{
      fontSize:20,
      marginTop: '5%',
      marginLeft: '5%',
    },

    textoutputENO:{ 
        position: 'absolute',
        left: '46%',
        top: '2.5%',
        width: '50%',
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,
    },

    textoutputMC:{
        position: 'absolute',
        left: '46%',
        top: '9%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },

    textoutputC:{
        position: 'absolute',
        left: '46%',
        top: '15.5%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },

    textoutputSC:{
        position: 'absolute',
        left: '46%',
        top: '22%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      

    },

    textoutputDesc:{
        position: 'absolute',
        left: '46%',
        top: '28.2%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },

    textoutputF:{
        position: 'absolute',
        left: '46%',
        top: '34.5%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },

    textoutputSD:{
        position: 'absolute',
        left: '46%',
        top: '41%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },

    textoutputSB:{
        position: 'absolute',
        left: '46%',
        top: '47%',
        width: "50%",
        height: '4%',
        backgroundColor: "transparent",
        borderColor: 'black',
        borderWidth: 1,
        borderRadius: 5,      
    },



    button:{
      marginTop: '5%',
      marginLeft:'20%',
      width : '60%',
      height:'5%',
      backgroundColor :'red',
      borderRadius: 18, 
      borderWidth: 2,

      
    },

    buttontext:{
      textAlign:'center',      
      fontWeight: 'bold',
      fontSize:25,
    },
    
  });

const styles1 = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "paleturquoise",
    },

    textheader:{
      fontSize:20,
      marginTop: '5%',
      marginLeft: '3%',
    },

    textinputENO:{     
      color: 'red',
      position: 'absolute',
      backgroundColor: "gray",
      left: '47%',
      top: '2.5%',
      width: '50%',
      height: '4%',
      borderColor: 'black',
      borderWidth: 1,
      borderRadius: 5,     
      fontSize:14
    },

    textinputENA:{
      position: 'absolute',
      backgroundColor: "gray",
      left: '47%',
      top: '9%',
      width: "50%",
      height: '4%',
      borderColor: 'black',
      borderWidth: 1,
      borderRadius: 5,   
    },

    textinputSGG:{
      position: 'absolute',
      left: '47%',
      top: '15.5%',
      width: "50%",
      height: '4%',
      backgroundColor: "gray",
    },

    textinputDP:{
      left: '47%',
      position: 'absolute',
      top: '22%',
      backgroundColor: "gray",
      width: "50%",
      height: '4%'
    },

    button:{
      marginTop: '5%',
      marginLeft:'28%',
      width : '45%',
      height:'5%',
      backgroundColor :'red',
      borderRadius: 18, 
      borderWidth: 2,
      
    },

    buttontext:{
      textAlign:'center',      
      fontWeight: 'bold',
      fontSize:25,
    },


      
  });

export default RetrievalScreen;