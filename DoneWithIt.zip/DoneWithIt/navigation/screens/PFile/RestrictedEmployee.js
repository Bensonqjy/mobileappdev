import React, { useEffect, useState } from 'react';
import { View, Table, Row } from 'react-native-table-component';
import { StyleSheet, Text } from 'react-native';

const RestrictedEmployeeScreen = () => {
  const [tableData, setTableData] = useState([]); // Initialize tableData state

  useEffect(() => {
    fetch('http://192.168.42.249:5287/api/RestrictedEmployee/GetRestrictedEmployee')
      .then((response) => response.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setTableData(mapDataToColumns(data));
        } else {
          // Handle non-array response (e.g., convert an object to an array)
          const dataArray = Object.values(data); // Convert object values to an array
          setTableData(mapDataToColumns(dataArray));
        }
      })
      .catch((error) => console.error(error));
  }, []);

  // Custom mapping function
  const mapDataToColumns = (data) => {
    return data.map((item) => ({
      sggid: item.sggid,
      empid: item.empid,
      name: item.name,
    }));
  };

  const styles = StyleSheet.create({
    container: { flex: 1, padding: 16, paddingTop: 30, backgroundColor: '#fff' },
    head: { height: 40, backgroundColor: '#f1f8ff' },
    text: { margin: 6 },
    row: { height: 30, backgroundColor: '#f9f9f9' },
  });

  return (
    <View style={styles.container}>
      <Table borderStyle={{ borderWidth: 2, borderColor: '#c8e1ff' }}>
        <Row data={['sggid', 'empid', 'name']} style={styles.head} textStyle={styles.text} />
        {tableData.map((rowData, index) => (
          <Row
            key={index}
            data={rowData}
            style={[styles.row, { backgroundColor: index % 2 === 0 ? '#f9f9f9' : 'white' }]
            }
            textStyle={styles.text}
          />
        ))}
      </Table>

    </View>
  );
};

export default RestrictedEmployeeScreen;
