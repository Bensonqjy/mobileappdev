import * as React from 'react'
import { View, Text, ScrollView, useWindowDimensions, StyleSheet, TextInput, Button, ImageBackground, TouchableOpacity } from 'react-native'
import { useState, useEffect } from 'react'
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import { Dropdown } from 'react-native-element-dropdown';
import { Ionicons } from '@expo/vector-icons';
import { getUserClaims } from '../controller/ClaimController.js'

const data = [
    { label: 'None', value: '1' },
    { label: 'Oldest', value: '2' },
    { label: 'Newest', value: '3' },
    { label: 'Most Expensive', value: '4' },
    { label: 'Cheapest', value: '5' },
    { label: 'Acceptance', value: '6' },
    { label: 'Most Attachment', value: '7' },
];

const ViewClaimsRoute = ({navigation}) => {

    const [value, setValue] = useState(1);
    const [isFocus, setIsFocus] = useState(false);
    const [search, setSearch] = useState("");
    const [userClaims, setUserClaims] = useState([{"test": "test"}]);
    const [buttonClicked, setButtonClicked] = useState(false);
    const [displayText, setDisplayText] = useState("Loading...");

    useEffect(()=>{
        // getUserClaims(value);
        if (value !== 1) {
            setButtonClicked(false);
            setSearch("");
            setUserClaims([{"test": "test"}])
        }
        switch (value) {
            case '1': setDisplayText("Displaying Claims..."); break;
            case '2': setDisplayText("Displaying Oldest Claims..."); break;
            case '3': setDisplayText("Displaying Newest Claims..."); break;
            case '4': setDisplayText("Displaying Most Expensive Claims..."); break;
            case '5': setDisplayText("Displaying Cheapest Claims..."); break;
            case '6': setDisplayText("Displaying Claims With Acceptance..."); break;
            case '7': setDisplayText("Displaying Most Attachments Claims..."); break;
        }
       // getUserClaims(value, "23");
    }, [value]);

    return (
            <ScrollView style={{ flex: 1, backgroundColor: "lightgreen" }}>
                <View style={styles.rowContainer}>
                    <View style={{flex: 0.8, marginRight: '2%', flexDirection: 'row'}}>
                        <TextInput
                            placeholder=" Claim ID"
                            onChangeText={(search)=>setSearch(search)}
                            value={search}
                            keyboardType="numeric"
                            style={{borderColor: 'grey', borderTopLeftRadius: 15, borderBottomLeftRadius: 15, borderWidth: 2, fontSize: 15, backgroundColor: 'white', flex: 0.8, paddingLeft: '2%'}}
                        />
                        <TouchableOpacity onPress={()=>{setValue(1); setButtonClicked(true); setUserClaims([])}}>
                        <View style={styles.searchButtonContainer}>
                            <Ionicons
                                name={'search'}
                                size={25}
                                color={'white'}
                                style={{marginLeft: '1%'}}
                            />
                            {/* <Text style={styles.buttonText}>Search</Text> */}
                        </View>
                        </TouchableOpacity>
                    </View>
                    {/* <View style={styles.buttonContainer}><Button icon={'list'} title={'search'} sty onPress={()=>{setValue(1); setButtonClicked(true); setUserClaims([])}} style={styles.rowComponent1} color='purple' borderRadius='50px'></Button></View> */}
                    <View style={{flex: 1, flexDirection: 'row'}}>
                        <Text style={{flex: 1, marginTop: '6%'}}>Filter By:</Text>
                        <Dropdown
                            data={data}
                            maxHeight={300}
                            labelField="label"
                            valueField="value"
                            placeholder={!isFocus ? 'None' : '...'}
                            value={value}
                            onFocus={() => setIsFocus(true)}
                            onBlur={() => setIsFocus(false)}
                            onChange={item => {
                                setValue(item.value);
                                setIsFocus(false);
                            }}
                            style={styles.dropdown}
                        />
                    </View>
                </View>
                
                <Text style={{textAlign: 'center', fontSize: 26, fontWeight: 'bold', marginTop: 10}} onPress={()=>navigation.navigate("Home")}>Your Claims: </Text>
                {
                (userClaims.length === 0 && buttonClicked === true) ? (
                    <Text style={styles.centralise}>No claims found, make sure claim ID entered belongs to YOU, to view all claims again, select any filter</Text>
                ) : (
                    (userClaims.length === 0) ? (
                        <Text style={styles.centralise}>You do not have any claims</Text>
                    ) : (
                       <Text style={styles.centralise}>{displayText}</Text>
                    )
                )
                }
            </ScrollView>
    );
}

const DisplayText = () => {

}

const AddClaimsRoute = () => {
    return (
    <ScrollView style={{ flex: 1 }}>
        <Text>Add claim Tab</Text>
    </ScrollView>
    );
}

const ApproveClaimsRoute = () => {
    return (
    <ScrollView style={{ flex: 1 }}>
        <Text>Approve claim Tab</Text>
    </ScrollView>
    );
}

const ProcessClaimsRoute = () => {
    return (
        <ScrollView style={{ flex: 1 }}>
            <Text>Proccess claim Tab</Text>
        </ScrollView>
    );
}

const renderScene = SceneMap({
    first: ViewClaimsRoute,
    second: AddClaimsRoute,
    third: ApproveClaimsRoute,
    fourth: ProcessClaimsRoute,
});

const ClaimsScreen = ()=> {
    const layout = useWindowDimensions();

    const [index, setIndex] = useState(0);
    const [userClaims, setUserClaims] = useState([]);
    const [position, setPosition] = useState("CEOO");
    const [inChargeOfClaims, setInChargeOfClaims] = useState(true);
    const initialRoutes = [
        { key: 'first', title: 'View Claims', icon: 'list' },
        { key: 'second', title: 'Add Claims', icon: 'add' },
    ];
    
    if (position === "CEO") {
        initialRoutes.push({ key: 'third', title: 'Approve Claims', icon: 'add' });
    }
    if (inChargeOfClaims === true) {
        initialRoutes.push({ key: 'fourth', title: 'Proccess Claims', icon: 'add' });
    }
    const [routes, setRoutes] = useState(initialRoutes);

    useEffect(() => {
        // getUserClaims();
    }, [])

    

    return (
        <TabView
            navigationState={{ index, routes }}
            renderScene={renderScene}
            onIndexChange={setIndex}
            initialLayout={{ width: layout.width }}
            renderTabBar={(props) => (
                <TabBar
                    {...props}
                    indicatorStyle={{ backgroundColor: 'blue' }}
                    style={{ backgroundColor: 'white' }}
                    labelStyle={{ color: 'black' }}
                    
                    renderIcon={({ route, focused }) => (
                        <Ionicons
                        name={route.icon}
                        size={24}
                        color={focused ? 'blue' : 'black'}
                        />
                    )
                    }
                />
            )}
        />
    );
};

const styles = StyleSheet.create({
    
    label: {
        position: 'absolute',
        backgroundColor: 'white',
        left: 22,
        top: 8,
        zIndex: 999,
        paddingHorizontal: 8,
        fontSize: 14,
    },
    dropdownContainer: {
        flexDirection: 'row',
        marginTop: 15,
    },
    rowContainer: {
        flexDirection: 'row',
        display: 'flex',
        margin: '3%',
    },
    rowComponent1: {
        flex: 1,
    },
    rowComponent2: {
        flex: 2,
    },
    dropdown: {
        borderColor: 'lightblue',
        borderWidth: 3,
        borderRadius: 15,
        backgroundColor: 'cyan',
        flex: 2,
        paddingLeft: '2%'
      },
      placeholderStyle: {
        fontSize: 16,
        paddingLeft: 20
      },
      centralise: {
        textAlign: 'center',
        marginTop: '2%',
        justifyContent: 'center',
      },
    //   buttonContainer: {
    //     borderRadius: 50,
    //     marginTop: '1%',
    //     paddingBottom: '1%',
    //     // overflow: 'hidden', // Set borderRadius to half the button's width or height for a perfect circle
    //   },
    searchButtonContainer: {
        backgroundColor: 'blue', // Background color of the button
        borderTopRightRadius: 15,
        borderBottomRightRadius: 15,
        paddingVertical: '12%', // Vertical padding to ensure the content doesn't overflow
        paddingLeft: '5%',
        flexDirection: 'row',
        marginRight: '2%',
        borderColor: 'white',
        borderWidth: 2.5,
      },
      buttonText: {
        color: 'white', // Text color
        fontSize: 16, // Text size
        textAlign: 'center', // Center the text horizontally within the button
      },
})

export default ClaimsScreen;