import * as React from 'react'
import { View, Text, Alert, StyleSheet, ScrollView, SafeAreaView } from 'react-native'
import { WebView } from 'react-native-webview'
import { useState, useEffect } from 'react';
import axios from 'axios';

const HomeScreen = ({navigation}) => {

    const [UserInfo, setUserInfo] = useState([]);
    const url1 = 'https://jsonplaceholder.typicode.com/posts';
    const url2 = 'http://localhost:5052/api/Email/GetAllName';
    const url3 = 'http://localhost:5052/api/Claims/Testing';
    const url4 = 'http://localhost:5052/api/Claims/ObjectTest';
  
    const [data, setData] = useState([]);
  
    // Use useEffect to call getData when the component mounts
    useEffect(() => {
        axios.get(url3, {withCredentials: true})
        .then((response) => {
            // Handle the data received from the API
            console.log("Response Headers: ", response.headers)
            setData(response);
        })
        .catch((error) => {
            if (axios.isCancel(error)) {
                console.log("Request canceled:", error.message);
            }
            else if (error.response) {
                console.log("Response error: ", error.response)
            }
            else if (error.request) {
                console.log("Request error: ", error.request)
            }
            else {
                console.log("Error: ", error.message)
            }
        });

        console.log(data);
    }, []); // The empty dependency array means this effect runs once on component mount

    async function getInfo() {
        fetch(url)
        .then(response => response.json())
        .then(result => setData(result))
        .catch((error)=>console.log(error));
    }
    
    {/*
        <Text onPress={()=>Alert.alert("This is Home screen", "Where would you like to go?", [
            {text: "About", onPress: () => navigation.navigate("About")},
            {text: "Employees", onPress: () => navigation.navigate("Employees")},
            {text: "Claims", onPress: () => navigator.navigate("Claims")},
            {text: "Settings", onPress: () => navigation.navigate("Settings")}
        ])} 
        style={{fontSize: 26, fontWeight: 'bold'}}>
            Home Screen
        </Text>
    */}

    {/*
        <ScrollView style={{flex: 1, alignItems: 'center', justifyContent: 'center'}}>
            {data.length === 0 ? (
                <Text>You do not have any particular</Text>
            ) : (
                data.map((post) => (
                    <SafeAreaView>
                    <Text>{post.id}</Text>
                    <Text>{post.userId}</Text>
                    </SafeAreaView>
                ))
            )}
        </ScrollView>
    */}
    

    return (
        <ScrollView>
            <Text onPress={()=>Alert.alert("This is Home screen", "Where would you like to go?", [
                {text: "About", onPress: () => navigation.navigate("About")},
                {text: "Employees", onPress: () => navigation.navigate("Employees")},
                {text: "Claims", onPress: () => navigation.navigate("Claims")},
                {text: "Settings", onPress: () => navigation.navigate("Settings")}
            ])} 
            style={{fontSize: 35, fontWeight: 'bold', textAlign: 'center', justifyContent: 'center', color: 'green'}}>
                Home Screen
            </Text>
            {data.length === 0 ? (
                <Text style={styles.container}>You do not have any particulars</Text>
            ) : (
                data.map((post) => (
                    <SafeAreaView>
                    <Text style={styles.text}>Name: {post.name}</Text>
                    <Text style={styles.email}>Department: {post.departmentName}</Text>
                    </SafeAreaView>
                ))
            )}
        </ScrollView>
    );
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center'
    },
    webview: {
      flex: 1,
    },
    text: {
        textAlign: 'center',
        fontStyle: 'bold',
        fontSize: 20,
    },
    email: {
        textAlign: 'center',
        fontStyle: 'italic',
        color: 'blue',
        fontSize: 15,
    }
  });

export default HomeScreen;