// import React, { Component } from 'react';
// import { View, Button, Text } from 'react-native';
// import { UserAgentApplication } from 'react-native-msal';
// import { AuthenticationParameters } from 'react-native-msal';

// export default class Login extends Component {
//   constructor(props) {
//     super(props);

//     this.auth = new UserAgentApplication({
//       auth: {
//         clientId: 'f5ea6b0b-c379-45ae-a15b-6afd3be97def',
//         authority: 'https://login.microsoftonline.com/87ff9ae9-e18b-4770-8820-8890e68a65c6',
//         redirectUri: 'exp://85-nny.anonymous.donewithit.exp.direct:80/--/auth',
//       },
//     });

//     this.state = {
//       accessToken: null,
//       userInfo: null,
//     };
//   }

//   login = async () => {
//     try {
//       const authResult = await this.auth.login();
//       const accessToken = authResult.accessToken;

//       if (accessToken) {
//         this.setState({ accessToken });
//         this.getUserInfo();
//       }
//     } catch (error) {
//       console.error(error);
//     }
//   }

//   getUserInfo = async () => {
//     try {
//       const authParameters = new AuthenticationParameters();
//       authParameters.scopes = ['openid', 'profile'];

//       const userInfo = await this.auth.acquireTokenSilent(authParameters);
//       this.setState({ userInfo });
//     } catch (error) {
//       console.error(error);
//     }
//   }

//   logout = () => {
//     this.auth.logout();
//     this.setState({ accessToken: null, userInfo: null });
//   }

//   render() {
//     const { accessToken, userInfo } = this.state;

//     return (
//       <View>
//         {accessToken ? (
//           <Button title="Logout" onPress={this.logout} />
//         ) : (
//           <Button title="Login with Microsoft" onPress={this.login} />
//         )}

//         {userInfo && (
//           <View>
//             <Text>Welcome, {userInfo.displayName}</Text>
//             <Text>Email: {userInfo.userPrincipalName}</Text>
//           </View>
//         )}
//       </View>
//     );
//   }
// }

import React from 'react';
import { View, Text, Button, SafeAreaView } from 'react-native';
import MicrosoftLogin from "react-microsoft-login";
// import { authorize, signOut } from 'react-native-app-auth';
// import { useNavigation } from '@react-navigation/native';

export default (props) => {
  const authHandler = (err, data) => {
    console.log(err, data);
  };

  return (
    <SafeAreaView>
       <View>
         <Text>Login Page</Text>
         <MicrosoftLogin clientId={'f5ea6b0b-c379-45ae-a15b-6afd3be97def'} authCallback={authHandler} />
       </View>
     </SafeAreaView>
  );
};

// const Login = () => {

//   const handleAuthorize = async () => {
//     try {
//       const result = await authorize({
//         issuer: 'https://login.microsoftonline.com/87ff9ae9-e18b-4770-8820-8890e68a65c6',
//         clientId: 'f5ea6b0b-c379-45ae-a15b-6afd3be97def',
//         redirectUrl: 'https://login.microsoftonline.com/common/oauth2/nativeclient',
//         scopes: ['openid', 'profile', 'email'],
//         serviceConfiguration: {
//           authorizationEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
//           tokenEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
//         },
//       });
//       console.log(result);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   const handleSignOut = async () => {
//     try {
//       await signOut(options);
//       console.log('User signed out');
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     // <NavigationContainer>
//     //   <Stack.Navigator>
//     //     <Stack.Screen name="Login" component={LoginComponent} />
//     //   </Stack.Navigator>
//     // </NavigationContainer>
//     <SafeAreaView>
//       <View>
//         <Text>Login Page</Text>
//         <Button title="Login with Microsoft Account" onPress={handleAuthorize} />
//       </View>
//     </SafeAreaView>
//   );
// };

// export default Login;

// import React from 'react'
// import {Text, SafeAreaView, StatusBar} from 'react-native'

// const Login = () => {
//   return (
//     <SafeAreaView style={{marginTop: StatusBar.currentHeight}}>
//       <Text style={{color: 'orange', fontSize: 32, textAlign: 'center',}}>Login Page Test</Text>
//       <Text>Stupid trash in cannot work 💩 stuff</Text>
//     </SafeAreaView>
//   )
// }

// export default Login




// const Login = () => {
//   const navigation = useNavigation();
//   const config = {
//     clientId: 'f5ea6b0b-c379-45ae-a15b-6afd3be97def',
//     redirectUrl: 'exp://85-nny.anonymous.donewithit.exp.direct:80/--/auth',
//     scopes: ['openid', 'profile', 'email', 'offline_access', 'User.Read'],
//     serviceConfiguration: {
//       authorizationEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
//       tokenEndpoint: 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
//     },
//   };
  
//   const loginWithMicrosoft = async () => {
//     try {
//       const result = await authorize(config);

//       // If the user successfully logs in, navigate to the home page.
//       if (result.idToken) {
//         navigation.navigate('HomeScreen');
//       }
//     } catch (error) {
//       console.error('Authentication Error:', error);
//     }
//   };

//   return (+
//     // <NavigationContainer>
//     //   <Stack.Navigator>
//     //     <Stack.Screen name="Login" component={LoginComponent} />
//     //   </Stack.Navigator>
//     // </NavigationContainer>
//     <SafeAreaView>
//       <View>
//         <Text>Login Page</Text>
//         <Button title="Login with Microsoft" onPress={loginWithMicrosoft} />
//       </View>
//     </SafeAreaView>
//   );
// };