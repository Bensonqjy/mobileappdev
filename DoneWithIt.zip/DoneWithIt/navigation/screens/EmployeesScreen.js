import * as React from 'react'
import { View, Text } from 'react-native'

const EmployeesScreen = ({navigation})=> {
    return (
        <View style={{flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: 'grey'}}>
            <Text onPress={()=>navigation.navigate("Home")} style={{fontSize: 26, fontWeight: 'bold', color: 'green', fontStyle: 'italic'}}>Employees Screen</Text>
        </View>
    );
};

export default EmployeesScreen;