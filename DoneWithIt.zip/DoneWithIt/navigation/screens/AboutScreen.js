
import * as React from 'react'
import { View, Text, StyleSheet } from 'react-native'
import { useEffect } from 'react'
import { WebView } from 'react-native-webview'

const AboutScreen = ({navigation})=> {


    return (
        <View style={styles.container}>
            <WebView
                source={{ uri: 'https://www.ssmc.com/AboutUs/AboutSSMC' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.reactnative.dev/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.react.dev/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.bing.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.gov.sg/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.dell.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.asus.com' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.acer.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.msi.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.microsoft.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.google.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
            <WebView
                source={{ uri: 'https://www.lenovo.com/' }} // Replace with the URL of the website you want to display.
                style={styles.webview}
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
      flex: 1,
    },
    webview: {
      flex: 1,
    },
  });

export default AboutScreen;