const API_URL = "http://localhost:5052/";

async function getUserClaims(value, empno) {
  let data;
  // wait for UserInfo to be updated
  // obtain all claims and attachment
  const formData = new FormData();
  // const empno = await UserInfo.empno;
  if (value === 1) {
    formData.append("id", empno);
  
    fetch(API_URL+"api/Claims/GetClaims", {
      method: "POST",
      body: formData
    })
    .then(response=>response.json())
    .then((result)=>{
      if (Array.isArray(result)) { // if the result is not null, set the claims
        data = result;
      }
    });
  }
  else if (value === 2) {
    
  }
  

  return (data);
}

