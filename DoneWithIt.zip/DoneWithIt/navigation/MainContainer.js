import * as React from 'react'
import { /*View, Text, SafeAreaView,*/ Platform } from 'react-native'
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator, Screen } from '@react-navigation/bottom-tabs';
import Ionicons from 'react-native-vector-icons/Ionicons'

// Screens
import SettingsScreen from './screens/SettingsScreen';
import HomeScreen from './screens/HomeScreen';
import EmployeesScreen from './screens/EmployeesScreen';
import ClaimsScreen from './screens/ClaimsScreen';
import AboutScreen from './screens/AboutScreen';
import RetrievalScreen from './screens/PFile/FileRetrieval';
import RestrictedEmployeeScreen from './screens/PFile/RestrictedEmployee';
import Login from './screens/Login';

// screen name
const homeName = "Home";
const aboutName = "About";
const employeesName = "Employees"
const claimsName = "Claims";
const settingsName = "Settings";
const retrievesName = "File Retrieval"
const fileviewName = "File View";
const REName = " RE List"


const Tab = createBottomTabNavigator();


export default function MainContainer() {

    const tabBarStyle = {
        padding: '2%', // Set padding for Android and iOS
        height: Platform.OS === 'android' ? '7%' : '10%', // Set different height for Android and iOS
      };

    return (
        <NavigationContainer>
            <Tab.Navigator 
                initialRouteName={homeName} // when first open app, set screen to Home
                screenOptions={({route}) => ({ // select route property from Tab.navigator
                    tabBarIcon: ({focused, color, size}) => { // select focused, color, size property from tabBarIcon
                        let iconName; // create string variable iconName first to store image name later
                        let rn = route.name; // store route name in rn
                        if (rn === homeName) { // if route name is equal to the 'Home'
                            iconName = (focused ? "home" : "home-outline"); // if focused is true, store home in iconName, else store home-outline
                        }
                        else if (rn === aboutName) {
                            iconName = (focused ? "information-circle" : "information-circle-outline"); // if focused is true, store list in iconName, else store list-outline
                        }
                        else if (rn === employeesName) {
                            iconName = (focused ? "people-circle" : "people-circle-outline"); // if focused is true, store list in iconName, else store list-outline
                        }
                        else if (rn === claimsName) {
                            iconName = (focused ? "layers" : "layers-outline"); // if focused is true, store list in iconName, else store list-outline
                        }
                        else if (rn === settingsName) {
                            iconName = (focused ? "settings" : "settings-outline"); // if focused is true, store settings in iconName, else store settings-outline
                        }

                        else if (rn === retrievesName) {
                            iconName = (focused ? "folder" : "folder-outline"); // if focused is true, store settings in iconName, else store settings-outline
                        } 

                        return <Ionicons name={iconName} size={size} color={color}/> // return the icon element and set the corresponding properties
                    },
                    tabBarActiveTintColor: "tomato",
                    tabBarInactiveTintColor: "grey",
                    tabBarLabelStyle: {
                        paddingBottom: '2%',
                        fontSize: 10
                    },
                    tabBarStyle: tabBarStyle,
                })}
                >
                <Tab.Screen name={homeName} component={HomeScreen}/>
                <Tab.Screen name={aboutName} component={AboutScreen}/>
                <Tab.Screen name={employeesName} component={EmployeesScreen}/>
                <Tab.Screen name={claimsName} component={ClaimsScreen}/>
                <Tab.Screen name={REName} component={RestrictedEmployeeScreen}/>
                <Tab.Screen name={settingsName} component={SettingsScreen}/>

            </Tab.Navigator>
        </NavigationContainer>
    );
}