// import { StatusBar } from 'expo-status-bar';
import { StyleSheet, Text, View, Image, SafeAreaView, ActivityIndicator, Button, Alert, ScrollView } from 'react-native';
import { useState, useEffect } from 'react';
// import { Table, Row, TableWrapper } from 'react-native-table-component';
import * as React from 'react'
import MainContainer from './navigation/MainContainer';
// import axios from 'axios';
import Login from './navigation/screens/Login.js'
import { useAsyncStorage } from '@react-native-async-storage/async-storage';

const API_URL = "http://localhost:5052/";

function App() {

  const [UserInfo, setUserInfo] = useState<any[]>([]);
  const url = "https://jsonplaceholder.typicode.com/posts";
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const { getItem } = useAsyncStorage('access_token');

  const [data, setData] = useState<any[]>([]);

  useEffect(() => {
    // Check if the user is logged in
    const checkUserLoggedIn = async () => {
      try {
        const accessToken = await getItem();
        // Check if the access token exists
        if (accessToken) {
          setIsLoggedIn(true);
        } else {
          setIsLoggedIn(false);
        }
      } catch (error) {
        console.error('Error checking login status: ', error);
        setIsLoggedIn(false); // Set as not logged in in case of an error
      }
    };

    checkUserLoggedIn();
  }, []);

  // Use useEffect to call getData when the component mounts
  useEffect(() => {
    
  }, []); // The empty dependency array means this effect runs once on component mount

  const getData = async () => {
    var email = "CHERRY.CHUA@SSMC.COM";
    // setUserEmail(accounts[0].username);
    // get user data
    const formData = new FormData();
    formData.append("email", email);

    fetch(API_URL + "api/Email/GetInfoByEmail", {
      method: "POST",
      body: formData
    })
      .then(response => {
        return response.json();
      })
      .then((result) => {
        if (Array.isArray(result)) { // if the result is not null, set the info
          setUserInfo(result);
          console.log("UserInfo:", result); // Add this line for debugging
        }
        if (result.length === 0) {
          var sggID = email.substring(0, 8);
          const formData2 = new FormData();
          formData2.append("sggid", sggID);
          fetch(API_URL + "api/Email/GetInfoBySGGID", {
            method: "POST",
            body: formData2
          })
            .then(response => response.json())
            .then((result) => {
              if (Array.isArray(result)) {
                setUserInfo(result);
              }
            })
        }

      });

  }

  {/*
    <ScrollView>
    {data.length === 0 ? (
      <Text>You do not have any particulars</Text>
    ) : (
      data.map((post) => (
        <SafeAreaView>
        <Text>{post.id}</Text>
        <Text>{post.userId}</Text>
        </SafeAreaView>
      ))
    )}
    </ScrollView>
      */}
  return (
    // isLoggedIn ? <MainContainer /> : <Login />
    // <MainContainer />
    <Login/>
  );
}

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 200, // Set the desired width
    height: 200, // Set the desired height
  },
});
