import express from 'express';
import { connect, query, close } from 'mssql';

const app = express();
const port = 3000;

// SQL Server configuration
const config = {
  user: 'your_username',
  password: 'your_password',
  server: 'your_server',
  database: 'your_database',
};

// API endpoint to get data from SQL Server
app.get('/api/data', async (res) => {
  try {
    await connect(config);
    const result = await query('SELECT * FROM YourTable');
    res.json(result.recordset);
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
  } finally {
    close();
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});

// import React from 'react';
// import { AppRegistry } from 'react-native';
// import { NavigationContainer } from '@react-navigation/native';
// import { createNativeStackNavigator } from '@react-navigation/native-stack';
// import Login from './navigation/screens/Login';
// import Home from './navigation/screens/HomeScreen';

// const Stack = createNativeStackNavigator();

// function App() {
//   return (
//     <NavigationContainer>
//       <Stack.Navigator>
//         <Stack.Screen name="Login" component={Login} />
//         <Stack.Screen name="Home" component={Home} />
//       </Stack.Navigator>
//     </NavigationContainer>
//   );
// }

// AppRegistry.registerComponent('YourAppName', () => App);